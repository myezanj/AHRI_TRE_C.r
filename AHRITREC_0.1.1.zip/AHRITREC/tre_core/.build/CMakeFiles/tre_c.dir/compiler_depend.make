# Empty compiler generated dependencies file for tre_c.
# This may be replaced when dependencies are built.
