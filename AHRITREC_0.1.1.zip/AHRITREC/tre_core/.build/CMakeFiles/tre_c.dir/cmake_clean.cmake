file(REMOVE_RECURSE
  "CMakeFiles/tre_c.dir/src/tre_c.c.obj"
  "CMakeFiles/tre_c.dir/src/tre_c.c.obj.d"
  "libtre_c.dll"
  "libtre_c.dll.a"
  "libtre_c.dll.manifest"
  "libtre_c.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/tre_c.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
